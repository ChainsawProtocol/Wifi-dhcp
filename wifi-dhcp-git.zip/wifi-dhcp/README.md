# Termux Wi-Fi diagnostics

A Termux script with a rotating JSON log, a persistent SQLite cache, and
Cloudflare response-header diagnostics. Includes a command to open Android's
Wi-Fi settings for manual DHCP configuration.

## Install and run

In Termux, install the dependencies and run from this directory:

```bash
pkg install python termux-am
bash wifi-dhcp.sh --help
bash wifi-dhcp.sh check https://example.com
bash wifi-dhcp.sh cache
bash wifi-dhcp.sh renew
```

`check` makes one GET request, inspects response headers, and caches its result
for five minutes. It does not follow redirects or retry automatically. A
`Retry-After` header can extend the cache lifetime. Customize a check with:

```bash
bash wifi-dhcp.sh check https://example.com --ttl 600 --timeout 15
```

Cloudflare header indicators and challenge pages are recorded separately.
`CF-Mitigated: challenge` identifies a challenge; a 403 status alone does not.
Missing indicators do not prove that Cloudflare is absent.

## DHCP limitation

Ordinary Termux without privileged Android access cannot configure Android's
IP assignment or force DHCP lease renewal. `renew` (also called `dhcp`) opens
Wi-Fi settings immediately and logs that manual action is required. Running
the script without arguments has the same behavior.

Select the connected network, open Edit / Advanced options, change IP settings
to DHCP, and save. Reconnect manually if necessary. Menu names vary by phone.
The script does not verify lease renewal. DHCP can assign the same local IP;
it does not request a new public IP from your Internet provider.

## Logs and cache

The default directory is `~/.local/state/wifi-dhcp/`:

- `events.jsonl`: JSON event log; rotates at 512 KiB with three backups.
- `detections.sqlite3`: response-header observations keyed by a URL hash.

Bodies, cookies, and complete URLs are not stored. Observations include the
origin, status, timestamps, Cloudflare indicators, Ray ID, and retry delay.
New state directories and files use private permissions. Set another directory
by placing `--data-dir PATH` before the command.

## Git repository and portable bundle

This folder includes Git metadata and an initial commit on `main`.
The accompanying `wifi-dhcp.bundle` is a self-contained copy of the commit
history. From this folder, restore another checkout with:

```bash
pkg install git
git clone ../wifi-dhcp.bundle wifi-dhcp-copy
```

The repository has no configured hosting remote. Cloning the bundle creates
a local `origin` pointing to that bundle.

## Validation

The script was checked using simulated HTTP responses for detection,
challenge classification, cache reuse and expiry, rate-limit cooldowns,
redirect handling, and private logs. Android launcher success and failure
were simulated. Execution on an Android device remains untested.
