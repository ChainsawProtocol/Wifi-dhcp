#!/data/data/com.termux/files/usr/bin/bash
# Termux Wi-Fi diagnostics. Install: pkg install python termux-am
# No-root mode: DHCP configuration/renewal requires action in Settings.
set -u
if command -v python3 >/dev/null 2>&1; then
    python_cmd=python3
elif command -v python >/dev/null 2>&1; then
    python_cmd=python
else
    printf 'Install Python first: pkg install python\n' >&2
    exit 1
fi
exec "$python_cmd" - "$@" <<'PYTHON'
import argparse
import hashlib
from http.client import HTTPException
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


def bounded_int(low, high):
    def parse(value):
        number = int(value)
        if not low <= number <= high:
            raise argparse.ArgumentTypeError(f'must be between {low} and {high}')
        return number
    return parse


parser = argparse.ArgumentParser(
    prog='wifi-dhcp.sh',
    description='Log and cache Cloudflare response headers; open DHCP settings.',
    epilog=('No root: this script cannot renew leases or change IP settings. '
            'DHCP can return the same local IP and does not rotate a public IP. '
            'Checks make one GET request, without redirects or automatic retries.'))
parser.add_argument('--data-dir', type=Path,
                    default=Path.home() / '.local' / 'state' / 'wifi-dhcp',
                    help='private log/cache directory')
commands = parser.add_subparsers(dest='command')
check_parser = commands.add_parser('check', help='inspect one HTTP(S) response')
check_parser.add_argument('url', help='HTTP(S) URL; embedded credentials are rejected')
check_parser.add_argument('--ttl', type=bounded_int(1, 86400), default=300,
                          help='cache lifetime in seconds (default: 300)')
check_parser.add_argument('--timeout', type=bounded_int(1, 60), default=10,
                          help='socket timeout in seconds (default: 10)')
commands.add_parser('cache', help='show saved observations, including expired ones')
commands.add_parser('dhcp', aliases=['renew'],
                    help='open Wi-Fi settings immediately; manual action required')
args = parser.parse_args()

# Protect newly created state. Never store bodies, cookies, or complete URLs.
os.umask(0o077)
state_dir = args.data_dir.expanduser()
try:
    state_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    log_path = state_dir / 'events.jsonl'
    logger = logging.getLogger('wifi-dhcp')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    handler = RotatingFileHandler(log_path, maxBytes=512 * 1024, backupCount=3,
                                  encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)
except OSError as exc:
    print(f'Cannot open log directory ({type(exc).__name__}).', file=sys.stderr)
    sys.exit(1)


def log(event, **fields):
    record = {'time': datetime.now(timezone.utc).isoformat(), 'event': event, **fields}
    logger.info(json.dumps(record, ensure_ascii=True, separators=(',', ':')))


def utc(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat()


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def url_info(value):
    if any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('URL must not contain control characters')
    parts = urlsplit(value)
    if parts.scheme.lower() not in ('http', 'https') or not parts.hostname:
        raise ValueError('supply a complete http:// or https:// URL')
    if parts.username is not None or parts.password is not None:
        raise ValueError('embedded credentials are not supported')
    host = parts.hostname.encode('idna').decode('ascii').lower()
    if ':' in host:
        host = '[' + host + ']'
    port = parts.port  # Reject invalid/out-of-range ports before any request.
    authority = host + (f':{port}' if port is not None else '')
    origin = parts.scheme.lower() + '://' + authority
    canonical = urlunsplit((parts.scheme.lower(), authority,
                           parts.path or '/', parts.query, ''))
    key = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
    return canonical, key, origin


def retry_after_seconds(value, now):
    if not value:
        return 0
    try:
        if value.isdigit():
            return min(int(value), 315360000)
        date = parsedate_to_datetime(value)
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        return max(0, min(int(date.timestamp() - now), 315360000))
    except (ValueError, TypeError, OverflowError):
        return 0


def open_dhcp_settings():
    log('dhcp_manual_required', automatic_renewal=False)
    print('No root: automatic DHCP renewal is unavailable. Opening Wi-Fi settings.')
    print('Select your network > Edit > Advanced options > IP settings > DHCP > Save.')
    print('Reconnect manually if needed. Menu names vary by phone.')
    print('DHCP can return the same local IP; public IP is controlled by your router/ISP.')
    am = shutil.which('am')
    if not am:
        log('settings_launch_failed', reason='am_missing')
        print('Install the launcher: pkg install termux-am', file=sys.stderr)
        print('Or open Settings > Wi-Fi manually.', file=sys.stderr)
        return 1
    try:
        result = subprocess.run([am, 'start', '-a', 'android.settings.WIFI_SETTINGS'],
                                capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.TimeoutExpired) as exc:
        log('settings_launch_failed', reason=type(exc).__name__)
        print('Could not open Settings; open Settings > Wi-Fi manually.', file=sys.stderr)
        return 1
    # Some Android launchers report an error on stdout with exit status zero.
    output = (result.stdout + result.stderr).lower()
    failed = result.returncode != 0 or any(
        marker in output for marker in ('error:', 'exception', 'permission denial'))
    log('settings_launch_failed' if failed else 'settings_launch_requested',
        returncode=result.returncode, automatic_renewal=False)
    if failed:
        print('Could not open Settings; open Settings > Wi-Fi manually.', file=sys.stderr)
        return 1
    print('Settings launch requested. Complete the steps there; renewal has not been verified.')
    return 0


def show(result, cached):
    print(json.dumps({**result, 'cached': cached}, indent=2, ensure_ascii=True))
    if result.get('challenge'):
        print('Cloudflare challenge observed. Complete it in a normal browser; no retry was made.')
    elif result.get('status') == 429:
        print('Rate limit observed. Wait before another request; no retry was made.')
    elif not result.get('cloudflare_observed'):
        print('No Cloudflare header indicators observed; this is not proof of absence.')


def check(db):
    try:
        url, key, origin = url_info(args.url)
    except (ValueError, UnicodeError) as exc:
        parser.error(str(exc))
    now = time.time()
    row = db.execute('SELECT result FROM detections WHERE cache_key = ?', (key,)).fetchone()
    if row:
        result = json.loads(row[0])
        if now < result['expires_epoch']:
            log('cache_hit', **result)
            show(result, cached=True)
            return 0
    request = Request(url, method='GET', headers={
        'User-Agent': 'Termux-Wifi-DHCP-Diagnostics/2.0', 'Accept': '*/*'})
    opener = build_opener(NoRedirect())
    try:
        try:
            response = opener.open(request, timeout=args.timeout)
        except HTTPError as exc:
            response = exc  # 3xx/4xx/5xx headers are diagnostic results too.
        with response:
            status = response.code
            headers = response.headers
            server = headers.get('Server', '')
            ray = headers.get('CF-Ray', '')
            challenge = headers.get('CF-Mitigated', '').strip().lower() == 'challenge'
            observed = (bool(ray) or server.strip().lower() == 'cloudflare'
                        or 'CF-Cache-Status' in headers or challenge)
            now = time.time()
            cooldown = retry_after_seconds(headers.get('Retry-After', '').strip(), now)
        expires = now + max(args.ttl, cooldown)
        result = {
            'origin': origin, 'checked_at': utc(now), 'expires_at': utc(expires),
            'expires_epoch': expires, 'status': status,
            'cloudflare_observed': observed, 'challenge': challenge,
            'rate_limited': status == 429, 'ray_id': ray[:256],
            'retry_after_seconds': cooldown,
        }
        db.execute('INSERT OR REPLACE INTO detections VALUES (?, ?)',
                   (key, json.dumps(result, ensure_ascii=True)))
        db.commit()
        log('http_check', **result)
        show(result, cached=False)
        return 0
    except (URLError, OSError, ValueError, HTTPException) as exc:
        log('http_error', origin=origin, error_type=type(exc).__name__)
        print(f'Request failed ({type(exc).__name__}); no retry or IP change was made.',
              file=sys.stderr)
        return 1


def main():
    print(f'Log: {log_path}')
    print(f'Cache: {state_dir / "detections.sqlite3"}')
    if args.command in (None, 'dhcp', 'renew'):
        return open_dhcp_settings()
    with sqlite3.connect(state_dir / 'detections.sqlite3', timeout=10) as db:
        db.execute('CREATE TABLE IF NOT EXISTS detections '
                   '(cache_key TEXT PRIMARY KEY, result TEXT NOT NULL)')
        if args.command == 'cache':
            results = [json.loads(row[0]) for row in db.execute(
                'SELECT result FROM detections ORDER BY cache_key')]
            now = time.time()
            for result in results:
                result['expired'] = now >= result['expires_epoch']
            print(json.dumps(results, indent=2, ensure_ascii=True))
            return 0
        return check(db)


try:
    sys.exit(main())
except KeyboardInterrupt:
    log('interrupted')
    sys.exit(130)
except (OSError, sqlite3.Error) as exc:
    print(f'Cannot access local log/cache ({type(exc).__name__}).', file=sys.stderr)
    sys.exit(1)
PYTHON
